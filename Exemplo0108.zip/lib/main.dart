import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Center(
        child: Container(
          // color: Colors.blue[200],
          // margin: const EdgeInsets.all(40),
          // // margin: EdgeInsets.only(left: 40, top: 80, right: 40, bottom: 80),
          width: 350,
          height: 350,
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: Colors.blue[300],
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [
                BoxShadow(
                    color: Colors.red, blurRadius: 20, offset: Offset(10, 10)),
                BoxShadow(
                    color: Colors.yellow,
                    blurRadius: 20,
                    offset: Offset(-10, -10))
              ]),
          child: Text('Olá Mundo'),
          alignment: Alignment.center,
          transform: Matrix4.rotationZ(0.1),
        ),
      ),
    );
  }
}
